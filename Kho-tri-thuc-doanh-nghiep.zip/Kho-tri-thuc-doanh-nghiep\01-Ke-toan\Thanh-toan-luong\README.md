# Thanh toán lương

Chỉ lưu bảng thanh toán đã duyệt, chứng từ ngân hàng và trạng thái thanh toán. Không lưu hồ sơ lao động đầy đủ tại đây.
