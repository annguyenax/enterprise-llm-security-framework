# Mẫu metadata tài liệu

```yaml
document_id: DOC-YYYY-0001
title: Ten tai lieu
department: accounting | it | hr | shared
owner: tai_khoan_chu_so_huu
classification: PUBLIC_INTERNAL | DEPARTMENT_INTERNAL | CONFIDENTIAL | STRICTLY_CONFIDENTIAL
status: DRAFT | REVIEW | APPROVED | ARCHIVED
effective_date: YYYY-MM-DD
retention_until: YYYY-MM-DD
related_employee_id: null
approved_by: null
version: 1.0
```

Với lương và hợp đồng, trường `related_employee_id` là bắt buộc để áp quyền theo từng nhân viên.
