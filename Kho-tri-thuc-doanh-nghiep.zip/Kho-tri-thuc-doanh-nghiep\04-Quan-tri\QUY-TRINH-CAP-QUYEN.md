# Quy trình cấp và thu hồi quyền

## Cấp quyền

1. Người dùng gửi yêu cầu theo mẫu.
2. Chủ sở hữu dữ liệu kiểm tra phạm vi và thời hạn.
3. Leader phòng hoặc người có thẩm quyền phê duyệt.
4. Quản trị viên cấp quyền đúng phạm vi, không cấp cao hơn yêu cầu.
5. Hệ thống ghi log người cấp, người nhận, lý do và ngày hết hạn.

## Thu hồi

- Nghỉ việc: khóa tài khoản và thu hồi quyền ngay.
- Chuyển phòng: thu hồi quyền phòng cũ trước khi cấp quyền phòng mới.
- Hết nhiệm vụ: quyền tạm thời tự động hết hạn.
- Hàng quý: leader xác nhận lại danh sách người có quyền.
