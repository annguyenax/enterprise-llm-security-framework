# KHO TRI THUC DOANH NGHIEP

Kho tri thức mẫu cho doanh nghiệp gồm ba phòng: Kế toán, IT và Nhân sự.

## Vai trò

- `superadmin`: quản trị tài khoản, cấu hình, sao lưu và nhật ký. Không mặc định đọc dữ liệu nghiệp vụ tối mật.
- `leader_accounting`, `leader_it`, `leader_hr`: quản lý và duyệt tài liệu trong phòng phụ trách.
- `employee_accounting`, `employee_it`, `employee_hr`: làm việc với tài liệu được giao.
- `employee`: xem tài liệu chung và hồ sơ cá nhân của chính mình.

## Cấu trúc

```text
00-Dung-chung/       Tài liệu toàn công ty
01-Ke-toan/          Chứng từ, hóa đơn, tài chính, thuế
02-IT/               Hướng dẫn, kỹ thuật, mã nguồn, vận hành
03-Nhan-su/          Hồ sơ, hợp đồng, chấm công, lương
04-Quan-tri/         Ma trận quyền, nhật ký, quy định quản trị
05-Luu-tru/          Tài liệu hết hiệu lực cần lưu dài hạn
Mau-bieu/            Mẫu metadata và yêu cầu cấp quyền
```

## Mức độ bảo mật

1. `PUBLIC_INTERNAL`: toàn bộ nhân viên được xem.
2. `DEPARTMENT_INTERNAL`: chỉ thành viên phòng ban liên quan.
3. `CONFIDENTIAL`: leader và người được chỉ định.
4. `STRICTLY_CONFIDENTIAL`: cấp quyền theo từng hồ sơ, bắt buộc ghi log.

## Cách sử dụng

1. Tạo nhóm người dùng theo vai trò trong `04-Quan-tri/access-control.yaml`.
2. Áp quyền theo `04-Quan-tri/MA-TRAN-PHAN-QUYEN.md`.
3. Mỗi tài liệu mới phải có metadata theo mẫu trong `Mau-bieu/MAU-METADATA.md`.
4. Lương và hợp đồng phải cấp quyền theo từng nhân viên, không chia sẻ cả thư mục cho toàn công ty.
5. Rà soát quyền hàng quý và thu hồi ngay khi nhân viên nghỉ việc hoặc chuyển phòng.

> Thư mục và YAML trong bộ khung này mô tả chính sách. Muốn quyền được thực thi, cần cấu hình ACL/RBAC tương ứng trên hệ thống lưu trữ thực tế.
