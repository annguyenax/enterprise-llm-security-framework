# Yêu cầu nhật ký kiểm toán

Ghi nhận tối thiểu:

- Đăng nhập thành công và thất bại.
- Xem hoặc tải dữ liệu tối mật.
- Tạo, sửa, xóa và khôi phục tài liệu.
- Chia sẻ tài liệu hoặc thay đổi quyền.
- Truy cập khẩn cấp.
- Xuất bảng lương hoặc danh sách hồ sơ nhân viên.

Nhật ký phải chống sửa đổi và chỉ người kiểm toán được chỉ định mới được xem.
