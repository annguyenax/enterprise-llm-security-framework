# Hồ sơ thuế

Lưu tờ khai, biên bản, báo cáo và tài liệu làm việc với cơ quan thuế. Quyền sửa chỉ dành cho nhóm thuế được giao nhiệm vụ.
