# Hóa đơn

Lưu hóa đơn đầu vào, đầu ra và hồ sơ đối soát. Không lưu mật khẩu hoặc khóa ký số trong thư mục này.
