# Quy định chia sẻ tài liệu

- Không tạo liên kết công khai cho tài liệu nội bộ.
- Không gửi file lương, hợp đồng hoặc hồ sơ nhân sự qua nhóm chat chung.
- Chỉ chia sẻ cho tài khoản doanh nghiệp và có ngày hết hạn khi chia sẻ tạm thời.
- Mọi thao tác tải xuống, chia sẻ, đổi quyền và xóa tài liệu mật phải được ghi log.
- Tài liệu hết hiệu lực phải chuyển sang kho lưu trữ, không xóa ngay.
