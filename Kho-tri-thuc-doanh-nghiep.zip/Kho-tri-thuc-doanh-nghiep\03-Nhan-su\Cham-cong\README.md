# Chấm công

Nhân viên xem dữ liệu của mình; leader xác nhận dữ liệu của nhóm; HR tổng hợp và khóa kỳ chấm công.
