# Cấu hình

Lưu mẫu cấu hình không chứa bí mật. Bí mật production phải được quản lý bằng secret manager và cấp quyền riêng.
