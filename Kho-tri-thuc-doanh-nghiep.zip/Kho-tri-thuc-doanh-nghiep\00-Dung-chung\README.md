# Kho dùng chung

Mức bảo mật mặc định: `PUBLIC_INTERNAL`.

Nội dung:

- Nội quy và chính sách công ty.
- Quy trình dùng chung.
- Biểu mẫu hành chính.
- Thông báo đã được phê duyệt.
- Tài liệu đào tạo chung.

Mọi nhân viên được xem và tải. Chỉ người phụ trách nội dung hoặc leader được tạo, sửa và công bố.
