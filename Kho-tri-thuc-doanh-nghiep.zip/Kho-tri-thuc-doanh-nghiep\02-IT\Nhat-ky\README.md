# Nhật ký kỹ thuật

Giới hạn thời gian lưu và che dữ liệu cá nhân. Không cho phép chỉnh sửa nhật ký đã ghi nhận.
