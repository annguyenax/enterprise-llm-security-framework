# Kho lưu trữ dài hạn

Chứa tài liệu hết hiệu lực nhưng vẫn phải lưu theo chính sách hoặc yêu cầu pháp lý.

- Giữ nguyên mức bảo mật của tài liệu gốc.
- Chuyển sang chế độ chỉ đọc.
- Gắn ngày hết hạn lưu trữ và người phê duyệt tiêu hủy.
- Không tự động xóa hợp đồng, chứng từ hoặc hồ sơ nhân sự khi chưa xác nhận nghĩa vụ lưu giữ.
