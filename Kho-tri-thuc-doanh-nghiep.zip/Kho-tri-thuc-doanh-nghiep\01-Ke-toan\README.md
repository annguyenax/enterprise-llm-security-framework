# Kho Kế toán

Chủ sở hữu nghiệp vụ: Leader Kế toán.

| Khu vực | Mức bảo mật | Người truy cập |
|---|---|---|
| Chung-tu | DEPARTMENT_INTERNAL | Kế toán phụ trách và Leader Kế toán |
| Hoa-don | DEPARTMENT_INTERNAL | Kế toán phụ trách và Leader Kế toán |
| Bao-cao-tai-chinh | CONFIDENTIAL | Leader Kế toán và người được chỉ định |
| Thue | CONFIDENTIAL | Nhóm thuế và Leader Kế toán |
| Thanh-toan-luong | STRICTLY_CONFIDENTIAL | Kế toán tiền lương, Leader Kế toán, HR lương |

Kế toán chỉ nhận dữ liệu lương cần thiết để thanh toán, hạch toán, thuế và bảo hiểm; không truy cập toàn bộ hồ sơ nhân sự.
