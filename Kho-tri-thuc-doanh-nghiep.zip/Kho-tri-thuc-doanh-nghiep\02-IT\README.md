# Kho IT

Chủ sở hữu nghiệp vụ: Leader IT.

| Khu vực | Mức bảo mật | Người truy cập |
|---|---|---|
| Huong-dan | PUBLIC_INTERNAL hoặc DEPARTMENT_INTERNAL | Theo nội dung |
| Tai-lieu-ky-thuat | DEPARTMENT_INTERNAL | IT |
| Ma-nguon | CONFIDENTIAL | Thành viên dự án |
| Cau-hinh | CONFIDENTIAL | IT vận hành được chỉ định |
| Nhat-ky | CONFIDENTIAL | IT vận hành và người kiểm toán được cấp quyền |

Mật khẩu, token và API key phải lưu trong secret manager, không lưu trực tiếp trong tài liệu hoặc mã nguồn.
