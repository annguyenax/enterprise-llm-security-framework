# Chứng từ

Lưu phiếu thu, phiếu chi, chứng từ ngân hàng và chứng từ hạch toán. Phân quyền theo người phụ trách kỳ kế toán hoặc nghiệp vụ.
