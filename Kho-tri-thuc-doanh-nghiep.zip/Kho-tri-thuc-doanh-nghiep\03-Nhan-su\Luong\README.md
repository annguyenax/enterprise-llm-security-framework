# Lương nhân viên

Các nhóm dữ liệu:

- Bảng lương tháng.
- Phiếu lương cá nhân.
- Thưởng, phụ cấp và khấu trừ.
- Thuế thu nhập cá nhân và bảo hiểm.
- Lịch sử điều chỉnh lương.

Quyền:

- HR phụ trách lương lập bảng lương.
- Leader HR duyệt.
- Kế toán tiền lương nhận bản đã duyệt để thanh toán và hạch toán.
- Nhân viên chỉ xem phiếu lương của chính mình.
- Leader phòng không mặc định xem mức lương chi tiết của nhân viên.

Quy ước tên phiếu lương: `PHIEULUONG-MaNhanVien-YYYY-MM.pdf`.
