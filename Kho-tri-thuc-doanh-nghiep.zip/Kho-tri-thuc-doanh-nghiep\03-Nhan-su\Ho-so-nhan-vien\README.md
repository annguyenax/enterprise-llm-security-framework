# Hồ sơ nhân viên

Mỗi nhân viên phải có thư mục hoặc hồ sơ riêng. Nhân viên chỉ được xem dữ liệu của chính mình; HR chỉ truy cập hồ sơ thuộc phạm vi phụ trách.
