# Ma trận phân quyền

Ký hiệu: `R` xem, `C` tạo, `U` sửa, `A` duyệt, `P` cấp quyền trong phạm vi, `-` không truy cập.

| Vai trò | Dùng chung | Phòng mình | Phòng khác | Lương | Hợp đồng của mình | Hợp đồng người khác | Quản trị/log |
|---|---|---|---|---|---|---|---|
| Superadmin | R/C/U/P | Quản trị quyền | - mặc định | - mặc định | R | - mặc định | R/C/U/P |
| Leader Kế toán | R | R/C/U/A/P | R khi được cấp | R bản thanh toán | R | - | - |
| Nhân viên Kế toán | R | R/C/U theo nhiệm vụ | - | R theo nhiệm vụ | R | - | - |
| Leader IT | R | R/C/U/A/P | R khi được cấp | - | R | - | R kỹ thuật theo nhiệm vụ |
| Nhân viên IT | R | R/C/U theo nhiệm vụ | - | - | R | - | - |
| Leader Nhân sự | R | R/C/U/A/P | R khi được cấp | R/C/U/A/P | R | R/C/U/A/P | - |
| Nhân viên HR | R | R/C/U theo nhiệm vụ | - | Theo nhiệm vụ | R | Theo nhiệm vụ | - |
| Nhân viên thường | R | R/C/U theo nhiệm vụ | - | R phiếu của mình | R | - | - |

## Quy tắc ngoại lệ

- Mọi quyền ngoài ma trận phải có người yêu cầu, người phê duyệt, lý do và ngày hết hạn.
- Quyền `P` của leader chỉ áp dụng trong phòng phụ trách.
- Superadmin vận hành hạ tầng không đồng nghĩa với quyền đọc dữ liệu nghiệp vụ.
- Truy cập khẩn cấp phải dùng cơ chế break-glass và được kiểm tra sau sự kiện.
