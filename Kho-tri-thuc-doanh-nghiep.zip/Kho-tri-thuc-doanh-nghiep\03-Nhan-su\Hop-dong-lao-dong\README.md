# Hợp đồng lao động

Phân quyền theo từng hợp đồng:

- HR phụ trách: tạo và cập nhật trước khi ký.
- Leader HR: kiểm tra và duyệt.
- Người đại diện công ty: xem và ký.
- Nhân viên: xem, ký và tải hợp đồng của chính mình.
- Kế toán: chỉ xem trường tài chính cần cho nghiệp vụ được giao.

Sau khi ký, bản gốc không được sửa đè. Mọi thay đổi phải tạo phụ lục hoặc phiên bản mới.

Quy ước tên: `HDLD-MaNhanVien-NgayHieuLuc-PhienBan.pdf`.
