# Tài liệu kỹ thuật

Lưu kiến trúc, sơ đồ hệ thống, tiêu chuẩn phát triển và quy trình triển khai.
