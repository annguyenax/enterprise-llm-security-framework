# Phiếu yêu cầu cấp quyền

- Người yêu cầu:
- Tài khoản cần cấp:
- Phòng ban:
- Thư mục hoặc hồ sơ:
- Quyền cần cấp: xem / tạo / sửa / duyệt / tải xuống
- Lý do nghiệp vụ:
- Ngày bắt đầu:
- Ngày hết hạn:
- Chủ sở hữu dữ liệu phê duyệt:
- Người thực hiện cấp quyền:
- Mã yêu cầu:
