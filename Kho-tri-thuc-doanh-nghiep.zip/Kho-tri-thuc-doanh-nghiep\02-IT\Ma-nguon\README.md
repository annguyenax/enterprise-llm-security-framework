# Mã nguồn

Chỉ thành viên dự án được truy cập. Nên lưu mã nguồn trong hệ thống Git có bảo vệ nhánh và kiểm tra lịch sử thay đổi.
