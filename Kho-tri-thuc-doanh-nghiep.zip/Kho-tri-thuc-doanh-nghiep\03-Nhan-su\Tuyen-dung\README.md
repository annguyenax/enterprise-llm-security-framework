# Tuyển dụng

Lưu hồ sơ ứng viên, lịch phỏng vấn và kết quả đánh giá. Chỉ nhóm tuyển dụng và người phỏng vấn liên quan được truy cập.
