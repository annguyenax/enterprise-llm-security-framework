# Kho Nhân sự

Chủ sở hữu nghiệp vụ: Leader Nhân sự.

| Khu vực | Mức bảo mật | Người truy cập |
|---|---|---|
| Ho-so-nhan-vien | STRICTLY_CONFIDENTIAL | HR phụ trách, Leader HR, chính nhân viên với hồ sơ của mình |
| Hop-dong-lao-dong | STRICTLY_CONFIDENTIAL | HR phụ trách, Leader HR, người ký và chính nhân viên |
| Luong | STRICTLY_CONFIDENTIAL | HR lương, Leader HR, Kế toán lương theo phạm vi |
| Cham-cong | CONFIDENTIAL | HR phụ trách, leader liên quan và chính nhân viên |
| Tuyen-dung | CONFIDENTIAL | Nhóm tuyển dụng và leader liên quan |
| Danh-gia | STRICTLY_CONFIDENTIAL | HR, leader trực tiếp và chính nhân viên theo quy trình |
