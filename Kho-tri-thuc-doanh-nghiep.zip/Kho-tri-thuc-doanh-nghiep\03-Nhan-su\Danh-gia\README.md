# Đánh giá nhân viên

Chỉ HR, leader trực tiếp và nhân viên liên quan được truy cập theo từng giai đoạn của quy trình đánh giá.
