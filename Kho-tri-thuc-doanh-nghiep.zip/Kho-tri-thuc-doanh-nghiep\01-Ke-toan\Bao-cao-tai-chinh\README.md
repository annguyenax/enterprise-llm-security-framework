# Báo cáo tài chính

Chỉ Leader Kế toán, ban lãnh đạo và người được chỉ định được xem. Bản chưa duyệt phải gắn trạng thái `DRAFT`.
